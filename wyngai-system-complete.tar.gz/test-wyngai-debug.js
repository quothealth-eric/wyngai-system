// Debug WyngAI Error Handling
const testWyngAIDebug = async () => {
  console.log('🔧 Testing WyngAI Error Handling and Debugging...\n');

  const deploymentUrl = 'https://wyng-lite-lw0hrk9n5-quothealth-erics-projects.vercel.app';

  console.log(`🔗 Testing: ${deploymentUrl}/api/wyngai\n`);

  // Test both healthcare and non-healthcare questions
  const testQuestions = [
    {
      type: "Healthcare (should work)",
      question: "What are ERISA appeal deadlines?"
    },
    {
      type: "Healthcare (should work)",
      question: "How do I appeal a denied claim?"
    },
    {
      type: "Non-healthcare (should fail and fallback)",
      question: "What's the weather today?"
    },
    {
      type: "Non-healthcare (should fail and fallback)",
      question: "How do I cook pasta?"
    },
    {
      type: "Edge case (should handle gracefully)",
      question: ""
    },
    {
      type: "Edge case (should handle gracefully)",
      question: "a"
    }
  ];

  for (const test of testQuestions) {
    console.log(`🧪 ${test.type}: "${test.question}"`);

    try {
      const response = await fetch(`${deploymentUrl}/api/wyngai`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: test.question,
          max_results: 3,
          include_citations: true
        })
      });

      if (!response.ok) {
        console.log(`❌ HTTP Error: ${response.status} ${response.statusText}`);
        console.log('---\n');
        continue;
      }

      const data = await response.json();

      if (data.error) {
        console.log(`❌ API Error: ${data.error}`);
      } else {
        const authorityScore = data.metadata?.avg_authority_rank || 0;
        const sourcesCount = data.sources?.length || 0;
        const topicsFound = data.metadata?.top_topics || [];

        console.log(`✅ Success:`);
        console.log(`   📊 Authority: ${(authorityScore * 100).toFixed(0)}%`);
        console.log(`   📚 Sources: ${sourcesCount}`);
        console.log(`   🏷️ Topics: ${topicsFound.slice(0, 3).join(', ')}`);
        console.log(`   📝 Answer: ${data.answer?.substring(0, 100)}...`);
      }

      console.log('---\n');
    } catch (error) {
      console.error(`❌ Network Error: ${error.message}`);
      console.log('---\n');
    }
  }

  console.log('🎯 Debug Testing Complete!');
  console.log('Expected behavior:');
  console.log('✅ Healthcare questions should succeed with high authority scores');
  console.log('⚠️ Non-healthcare questions should either fail gracefully or have low scores');
  console.log('🛡️ Edge cases should be handled without crashes');
};

// Run debug test
testWyngAIDebug();