#!/usr/bin/env node

/**
 * Integration test for WyngAI + Wyng-lite
 * Tests that the chat API uses WyngAI instead of external LLMs
 */

const https = require('http');

async function makeRequest(url, options, data) {
  return new Promise((resolve, reject) => {
    const req = https.request(url, options, (res) => {
      let body = '';
      res.on('data', (chunk) => body += chunk);
      res.on('end', () => {
        try {
          resolve({
            status: res.statusCode,
            data: JSON.parse(body)
          });
        } catch (e) {
          resolve({
            status: res.statusCode,
            data: body
          });
        }
      });
    });

    req.on('error', reject);

    if (data) {
      req.write(JSON.stringify(data));
    }

    req.end();
  });
}

async function testWyngAIHealth() {
  console.log('🔍 Testing WyngAI health...');

  try {
    const response = await makeRequest('http://localhost:8000/health', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });

    if (response.status === 200 && response.data.status === 'healthy') {
      console.log('✅ WyngAI service is healthy');
      console.log(`   - Index loaded: ${response.data.index_loaded}`);
      console.log(`   - Chunks: ${response.data.num_chunks}`);
      console.log(`   - Model: ${response.data.embedding_model}`);
      return true;
    } else {
      console.log('❌ WyngAI health check failed');
      console.log('   Response:', response);
      return false;
    }
  } catch (error) {
    console.log('❌ WyngAI service not reachable');
    console.log('   Error:', error.message);
    return false;
  }
}

async function testWyngLiteHealth() {
  console.log('🔍 Testing Wyng-lite health...');

  try {
    const response = await makeRequest('http://localhost:3000/api/health', {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' }
    });

    if (response.status === 200) {
      console.log('✅ Wyng-lite service is healthy');
      return true;
    } else {
      console.log('❌ Wyng-lite health check failed');
      console.log('   Response:', response);
      return false;
    }
  } catch (error) {
    console.log('❌ Wyng-lite service not reachable');
    console.log('   Error:', error.message);
    return false;
  }
}

async function testDirectWyngAI() {
  console.log('🔍 Testing WyngAI RAG directly...');

  try {
    const testQuestion = {
      question: "What are the requirements for ERISA claims appeals?",
      max_results: 5,
      require_citations: true
    };

    const response = await makeRequest('http://localhost:8000/ask', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, testQuestion);

    if (response.status === 200 && response.data.answer) {
      console.log('✅ WyngAI RAG responds correctly');
      console.log(`   - Citations: ${response.data.citations?.length || 0}`);
      console.log(`   - Processing time: ${response.data.processing_time_ms}ms`);
      console.log(`   - Answer preview: ${response.data.answer.substring(0, 100)}...`);
      return response.data.citations?.length > 0;
    } else {
      console.log('❌ WyngAI RAG test failed');
      console.log('   Response:', response);
      return false;
    }
  } catch (error) {
    console.log('❌ WyngAI RAG test error');
    console.log('   Error:', error.message);
    return false;
  }
}

async function testIntegratedChat() {
  console.log('🔍 Testing integrated chat (Wyng-lite → WyngAI)...');

  try {
    const testMessage = {
      message: "My insurance denied my surgery claim. What should I do?",
      benefits: {
        deductible: 1500,
        coinsurance: 20,
        copay: 30
      }
    };

    const response = await makeRequest('http://localhost:3000/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, testMessage);

    if (response.status === 200 && response.data.problem_summary) {
      console.log('✅ Integrated chat works correctly');
      console.log(`   - Problem summary: ${response.data.problem_summary.substring(0, 100)}...`);
      console.log(`   - Citations: ${response.data.citations?.length || 0}`);
      console.log(`   - Confidence: ${response.data.confidence}%`);
      console.log(`   - Appeal needed: ${response.data.needs_appeal}`);

      // Check if response contains WyngAI-specific indicators
      const hasAuthorativeCitations = response.data.citations?.some(c =>
        c.reference?.includes('CFR') || c.reference?.includes('USC')
      );

      if (hasAuthorativeCitations) {
        console.log('✅ Response includes authoritative citations (WyngAI working)');
        return true;
      } else {
        console.log('⚠️  Response lacks authoritative citations (may be using fallback)');
        return false;
      }
    } else {
      console.log('❌ Integrated chat test failed');
      console.log('   Response:', response);
      return false;
    }
  } catch (error) {
    console.log('❌ Integrated chat test error');
    console.log('   Error:', error.message);
    return false;
  }
}

async function runTests() {
  console.log('🚀 Running WyngAI Integration Tests\n');

  const tests = [
    { name: 'WyngAI Health', test: testWyngAIHealth },
    { name: 'Wyng-lite Health', test: testWyngLiteHealth },
    { name: 'WyngAI Direct', test: testDirectWyngAI },
    { name: 'Integrated Chat', test: testIntegratedChat }
  ];

  const results = [];

  for (const { name, test } of tests) {
    console.log(`\n📋 ${name}`);
    console.log('─'.repeat(50));

    const startTime = Date.now();
    const success = await test();
    const duration = Date.now() - startTime;

    results.push({ name, success, duration });
    console.log(`   Duration: ${duration}ms\n`);
  }

  // Summary
  console.log('📊 Test Results Summary');
  console.log('═'.repeat(50));

  const passed = results.filter(r => r.success).length;
  const total = results.length;

  results.forEach(({ name, success, duration }) => {
    const status = success ? '✅ PASS' : '❌ FAIL';
    console.log(`${status} ${name.padEnd(20)} (${duration}ms)`);
  });

  console.log('─'.repeat(50));
  console.log(`Result: ${passed}/${total} tests passed\n`);

  if (passed === total) {
    console.log('🎉 All tests passed! WyngAI integration is working correctly.');
    console.log('\n✨ Your website is now using internal AI instead of OpenAI/Anthropic!');
    process.exit(0);
  } else {
    console.log('❌ Some tests failed. Please check the errors above.');
    console.log('\nTroubleshooting:');
    console.log('1. Ensure both services are running: ./scripts/setup-wyngai-integration.sh');
    console.log('2. Check service logs for errors');
    console.log('3. Verify environment variables in .env.local');
    process.exit(1);
  }
}

// Run tests
runTests().catch(console.error);