// Test Live Production Website - getwyng.co
const testProductionLive = async () => {
  console.log('🌐 Testing LIVE PRODUCTION Website: getwyng.co\n');

  const productionUrl = 'https://getwyng.co';

  console.log(`🔗 Testing: ${productionUrl}/api/wyngai\n`);

  // Test comprehensive WyngAI system on live production
  const testQuestions = [
    {
      category: "✅ Healthcare - Should Work",
      question: "What are ERISA appeal deadlines for denied claims?",
      expectSuccess: true
    },
    {
      category: "✅ State Regulation - Should Work",
      question: "How do I file an external appeal in California?",
      expectSuccess: true
    },
    {
      category: "✅ Medicare - Should Work",
      question: "What are Medicare Part D appeal procedures?",
      expectSuccess: true
    },
    {
      category: "✅ Major Payer - Should Work",
      question: "What is Anthem's prior authorization process?",
      expectSuccess: true
    },
    {
      category: "❌ Non-Healthcare - Should Gracefully Fail",
      question: "What's the weather today?",
      expectSuccess: false
    }
  ];

  let productionTests = 0;
  let passedTests = 0;

  for (const test of testQuestions) {
    console.log(`🧪 ${test.category}`);
    console.log(`❓ Question: "${test.question}"`);

    productionTests++;

    try {
      const response = await fetch(`${productionUrl}/api/wyngai`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: test.question,
          max_results: 3,
          include_citations: true
        })
      });

      if (!response.ok) {
        console.log(`❌ HTTP Error: ${response.status} ${response.statusText}`);
        console.log('---\n');
        continue;
      }

      const data = await response.json();

      const authorityScore = data.metadata?.avg_authority_rank || 0;
      const sourcesCount = data.sources?.length || 0;
      const topicsFound = data.metadata?.top_topics || [];

      console.log(`📊 Authority Score: ${(authorityScore * 100).toFixed(0)}%`);
      console.log(`📚 Sources Found: ${sourcesCount}`);
      console.log(`🏷️ Topics: ${topicsFound.slice(0, 3).join(', ')}`);

      // Validate based on expectations
      if (test.expectSuccess) {
        if (authorityScore >= 0.7 && sourcesCount >= 3) {
          console.log(`✅ PASSED - High authority healthcare response`);
          passedTests++;
        } else {
          console.log(`⚠️ FAILED - Expected high authority, got ${(authorityScore * 100).toFixed(0)}%`);
        }
      } else {
        if (authorityScore < 0.1 && sourcesCount === 0) {
          console.log(`✅ PASSED - Correctly rejected non-healthcare question`);
          passedTests++;
        } else {
          console.log(`⚠️ FAILED - Should have rejected, but got ${(authorityScore * 100).toFixed(0)}%`);
        }
      }

      console.log('---\n');
    } catch (error) {
      console.error(`❌ Network Error: ${error.message}`);
      console.log('---\n');
    }
  }

  // Final production status
  console.log('🌐 LIVE PRODUCTION STATUS:');
  console.log(`📊 Tests: ${passedTests}/${productionTests} passed (${(passedTests/productionTests*100).toFixed(0)}%)`);

  if (passedTests === productionTests) {
    console.log('🏆 EXCELLENT! Your production website is fully operational!');
    console.log('✨ All comprehensive WyngAI improvements are LIVE on getwyng.co');
    console.log('🎯 Users are getting the enhanced healthcare regulation system!');
  } else if (passedTests >= productionTests * 0.8) {
    console.log('✅ GOOD! Your production website is mostly working well');
    console.log('⚠️ Some minor issues detected - may need attention');
  } else {
    console.log('❌ ISSUES DETECTED! Production website needs attention');
  }

  console.log('\n🚀 Production Deployment Summary:');
  console.log('   • Website: https://getwyng.co');
  console.log('   • WyngAI API: https://getwyng.co/api/wyngai');
  console.log('   • 28 healthcare regulation chunks');
  console.log('   • 10+ state regulations included');
  console.log('   • 5 major payer policies');
  console.log('   • Federal regulations (ERISA, ACA, etc.)');
  console.log('   • Enhanced search algorithm');
  console.log('   • Improved error handling');
};

// Test live production
testProductionLive();