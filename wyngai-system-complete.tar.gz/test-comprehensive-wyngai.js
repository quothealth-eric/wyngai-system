// Test Comprehensive WyngAI System
const testComprehensiveWyngAI = async () => {
  console.log('🧪 Testing Comprehensive WyngAI Healthcare Regulation System...\n');

  const deploymentUrl = 'https://wyng-lite-lw0hrk9n5-quothealth-erics-projects.vercel.app';

  console.log(`🔗 Testing: ${deploymentUrl}/api/wyngai\n`);

  // Comprehensive test questions covering all expanded areas
  const testQuestions = [
    {
      category: "Federal ERISA",
      question: "What is the ERISA appeal deadline for health plan claims?",
      expectedTopics: ["erisa", "appeals", "timeline"]
    },
    {
      category: "Medicare Coverage",
      question: "How do Medicare Part D appeals work for prescription drugs?",
      expectedTopics: ["medicare", "pharmacy", "appeals", "prior_authorization"]
    },
    {
      category: "State External Review - California",
      question: "What are California's independent medical review timelines?",
      expectedTopics: ["state_regulation", "external_review", "appeals"]
    },
    {
      category: "State External Review - New York",
      question: "How do I file an external appeal in New York for experimental treatment?",
      expectedTopics: ["state_regulation", "external_review", "appeals"]
    },
    {
      category: "State External Review - Texas",
      question: "What are Texas utilization review appeal rights?",
      expectedTopics: ["state_regulation", "appeals", "external_review"]
    },
    {
      category: "Major Payer - Anthem BCBS",
      question: "What is Anthem's prior authorization process for advanced imaging?",
      expectedTopics: ["payer_policy", "prior_authorization", "appeals"]
    },
    {
      category: "Major Payer - Cigna",
      question: "How does Cigna determine experimental treatment coverage?",
      expectedTopics: ["payer_policy", "coverage_determination", "appeals"]
    },
    {
      category: "Mental Health Parity",
      question: "What are mental health parity requirements under federal law?",
      expectedTopics: ["mental_health", "erisa", "federal_regulation"]
    },
    {
      category: "No Surprises Act",
      question: "What protections exist for emergency billing under the No Surprises Act?",
      expectedTopics: ["emergency_services", "billing", "federal_regulation"]
    },
    {
      category: "Multi-State Coverage",
      question: "How do appeal deadlines differ between Florida and Illinois?",
      expectedTopics: ["state_regulation", "appeals", "external_review"]
    }
  ];

  let passedTests = 0;
  const totalTests = testQuestions.length;

  for (const test of testQuestions) {
    console.log(`🔍 ${test.category}: ${test.question}`);

    try {
      const response = await fetch(`${deploymentUrl}/api/wyngai`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: test.question,
          max_results: 5,
          include_citations: true
        })
      });

      if (!response.ok) {
        console.log(`❌ Error: ${response.status} ${response.statusText}`);
        console.log('---\n');
        continue;
      }

      const data = await response.json();

      // Validate response quality
      const authorityScore = data.metadata?.avg_authority_rank || 0;
      const topicsFound = data.metadata?.top_topics || [];
      const sourcesCount = data.sources?.length || 0;

      console.log(`✅ Response Quality Analysis:`);
      console.log(`   📊 Authority Score: ${(authorityScore * 100).toFixed(0)}%`);
      console.log(`   📚 Sources Found: ${sourcesCount}`);
      console.log(`   🏷️ Topics: ${topicsFound.join(', ')}`);

      // Check if expected topics are covered
      const expectedCovered = test.expectedTopics.filter(topic =>
        topicsFound.some(found => found.includes(topic) || topic.includes(found))
      );

      console.log(`   ✓ Expected Topics Covered: ${expectedCovered.length}/${test.expectedTopics.length}`);

      // Quality scoring
      let qualityScore = 0;
      if (authorityScore >= 0.8) qualityScore += 2; // High authority
      if (sourcesCount >= 3) qualityScore += 2; // Multiple sources
      if (expectedCovered.length >= Math.ceil(test.expectedTopics.length * 0.5)) qualityScore += 2; // Topic coverage

      if (qualityScore >= 4) {
        console.log(`   🎯 Test PASSED (Quality Score: ${qualityScore}/6)`);
        passedTests++;
      } else {
        console.log(`   ⚠️ Test needs improvement (Quality Score: ${qualityScore}/6)`);
      }

      console.log('---\n');
    } catch (error) {
      console.error(`❌ Error testing: ${error.message}`);
      console.log('---\n');
    }
  }

  // Overall results
  console.log('🎯 Comprehensive Testing Complete!\n');
  console.log(`📊 Overall Results: ${passedTests}/${totalTests} tests passed (${(passedTests/totalTests*100).toFixed(0)}%)`);

  if (passedTests === totalTests) {
    console.log('🏆 EXCELLENT! Your comprehensive WyngAI system is working perfectly!');
  } else if (passedTests >= totalTests * 0.8) {
    console.log('✅ GREAT! Your WyngAI system is performing well with comprehensive coverage!');
  } else if (passedTests >= totalTests * 0.6) {
    console.log('⚠️ GOOD! Your WyngAI system is functional but could use some optimization.');
  } else {
    console.log('❌ NEEDS WORK! Your WyngAI system requires attention.');
  }

  console.log('\n✨ Your comprehensive WyngAI system now includes:');
  console.log('   • 28 total regulation chunks (expanded from 11)');
  console.log('   • 10+ state regulations (CA, NY, TX, FL, IL, PA, MI, OH, NC, GA)');
  console.log('   • 5 major payer policies (Anthem, Cigna, Humana, Kaiser, UHC)');
  console.log('   • Federal regulations (ERISA, ACA, MHPAEA, No Surprises Act)');
  console.log('   • 77-98% authority rankings across all sources');
  console.log('   • Enhanced topic coverage and keyword matching');
};

// Run comprehensive test
testComprehensiveWyngAI();