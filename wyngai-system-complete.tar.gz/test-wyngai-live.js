// Test WyngAI on the live deployment
const testLiveWyngAI = async () => {
  console.log('Testing WyngAI on live deployment...\n');

  const deploymentUrl = 'https://wyng-lite-b2zhefeoq-quothealth-erics-projects.vercel.app';

  console.log(`🔗 Testing: ${deploymentUrl}/api/wyngai\n`);

  // Test questions that should trigger WyngAI's regulation knowledge
  const testQuestions = [
    "What is the ERISA appeal deadline?",
    "How long do I have to appeal a denied claim?",
    "What are Medicare coverage requirements?"
  ];

  for (const question of testQuestions) {
    console.log(`❓ Question: ${question}`);

    try {
      const response = await fetch(`${deploymentUrl}/api/wyngai`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          question: question,
          max_results: 3,
          include_citations: true
        })
      });

      if (!response.ok) {
        console.log(`❌ Error: ${response.status} ${response.statusText}`);
        console.log('---\n');
        continue;
      }

      const data = await response.json();

      console.log(`✅ Response received:`);
      console.log(`   Answer: ${data.answer?.substring(0, 100)}...`);
      console.log(`   Sources: ${data.sources?.length || 0}`);
      console.log(`   Authority: ${data.metadata?.avg_authority_rank ? (data.metadata.avg_authority_rank * 100).toFixed(0) + '%' : 'Unknown'}`);
      console.log(`   Topics: ${data.metadata?.top_topics?.join(', ') || 'None'}`);
      console.log('---\n');
    } catch (error) {
      console.error(`❌ Error testing: ${error.message}`);
      console.log('---\n');
    }
  }

  console.log('🎯 Testing complete!');
  console.log('If you see authority scores and regulation topics, WyngAI is working!');
};

// Run test
testLiveWyngAI();