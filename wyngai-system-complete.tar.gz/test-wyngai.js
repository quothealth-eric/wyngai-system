// Test script to verify WyngAI is being used
const testWyngAI = async () => {
  console.log('Testing WyngAI integration...\n');

  // Test questions that should trigger WyngAI's regulation knowledge
  const testQuestions = [
    "What is the ERISA appeal deadline?",
    "How long do I have to appeal a denied claim?",
    "What are Medicare coverage requirements?"
  ];

  for (const question of testQuestions) {
    console.log(`Question: ${question}`);

    try {
      const response = await fetch('https://www.getwyng.co/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: question,
          conversationId: 'test-' + Date.now()
        })
      });

      const data = await response.json();

      // Check if response includes regulation citations (sign of WyngAI)
      const hasRegulationCitations = data.response?.includes('CFR') ||
                                     data.response?.includes('§') ||
                                     data.response?.includes('regulation');

      console.log(`Response received: ${data.response?.substring(0, 100)}...`);
      console.log(`Uses regulation citations: ${hasRegulationCitations ? '✓ YES' : '✗ NO'}`);
      console.log('---\n');
    } catch (error) {
      console.error(`Error testing: ${error.message}`);
    }
  }
};

// Run test
testWyngAI();