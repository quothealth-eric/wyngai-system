import { createWorker } from 'tesseract.js'

export interface OCRResult {
  text: string
  confidence: number
}

export async function performOCR(fileBuffer: Buffer, mimeType: string): Promise<OCRResult> {
  try {
    if (mimeType === 'application/pdf') {
      return await extractTextFromPDF(fileBuffer)
    } else if (mimeType.startsWith('image/')) {
      return await extractTextFromImage(fileBuffer)
    } else {
      throw new Error(`Unsupported file type: ${mimeType}`)
    }
  } catch (error) {
    console.error('OCR Error:', error)
    throw new Error('Failed to extract text from file')
  }
}

async function extractTextFromImage(imageBuffer: Buffer): Promise<OCRResult> {
  const worker = await createWorker()
  await worker.loadLanguage('eng')
  await worker.initialize('eng')

  try {
    const { data: { text, confidence } } = await worker.recognize(imageBuffer)

    // Limit text length to prevent excessive token usage
    const limitedText = text.slice(0, 10000)

    return {
      text: limitedText,
      confidence: confidence || 0
    }
  } finally {
    await worker.terminate()
  }
}

async function extractTextFromPDF(pdfBuffer: Buffer): Promise<OCRResult> {
  try {
    const pdfParse = (await import('pdf-parse')).default
    const data = await pdfParse(pdfBuffer)

    // If PDF has extractable text, use it
    if (data.text && data.text.trim().length > 50) {
      return {
        text: data.text.slice(0, 10000),
        confidence: 95 // High confidence for extractable PDF text
      }
    }

    // If PDF doesn't have extractable text, we would need to convert to images
    // For MVP, return extracted text even if limited
    return {
      text: data.text || 'Unable to extract text from this PDF',
      confidence: data.text ? 95 : 0
    }
  } catch (error) {
    console.error('PDF parsing error:', error)
    throw new Error('Failed to extract text from PDF')
  }
}

export function sanitizeOCRText(text: string): string {
  // Remove excessive whitespace
  text = text.replace(/\s+/g, ' ').trim()

  // Remove common OCR artifacts
  text = text.replace(/[^\w\s$.,()-]/g, ' ')

  // Limit length for API token efficiency
  if (text.length > 10000) {
    text = text.slice(0, 10000) + '...'
  }

  return text
}