import { NextRequest, NextResponse } from 'next/server'
import { supabase } from '@/lib/db'
import { performOCR, sanitizeOCRText } from '@/lib/ocr'
import { redactSensitiveInfo } from '@/lib/validations'

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData()
    const file = formData.get('file') as File

    if (!file) {
      return NextResponse.json(
        { error: 'No file provided' },
        { status: 400 }
      )
    }

    // Validate file type and size
    const allowedTypes = ['image/jpeg', 'image/png', 'application/pdf']
    if (!allowedTypes.includes(file.type)) {
      return NextResponse.json(
        { error: 'Invalid file type. Only JPEG, PNG, and PDF files are allowed.' },
        { status: 400 }
      )
    }

    const maxSize = 10 * 1024 * 1024 // 10MB
    if (file.size > maxSize) {
      return NextResponse.json(
        { error: 'File size too large. Maximum size is 10MB.' },
        { status: 400 }
      )
    }

    // Convert file to buffer
    const arrayBuffer = await file.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)

    // Generate unique filename
    const timestamp = Date.now()
    const randomId = Math.random().toString(36).substring(2, 15)
    const fileExtension = file.name.split('.').pop()
    const fileName = `${timestamp}_${randomId}.${fileExtension}`

    try {
      // Upload file to Supabase Storage
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('uploads')
        .upload(fileName, buffer, {
          contentType: file.type,
          cacheControl: '3600',
        })

      if (uploadError) {
        console.error('Supabase upload error:', uploadError)
        return NextResponse.json(
          { error: 'Failed to upload file' },
          { status: 500 }
        )
      }

      // Perform OCR on the file
      let ocrText = ''
      let ocrConfidence = 0

      try {
        const ocrResult = await performOCR(buffer, file.type)
        ocrText = sanitizeOCRText(ocrResult.text)
        ocrConfidence = ocrResult.confidence

        // Redact sensitive information from OCR text
        ocrText = redactSensitiveInfo(ocrText)
      } catch (ocrError) {
        console.error('OCR error:', ocrError)
        // Continue without OCR text if OCR fails
        ocrText = 'OCR processing failed'
        ocrConfidence = 0
      }

      // Save file metadata to database
      const { data: fileData, error: dbError } = await supabase
        .from('files')
        .insert({
          case_id: 'temp', // Will be updated when case is created
          file_name: file.name,
          file_type: file.type,
          file_size: file.size,
          storage_path: uploadData.path,
          ocr_text: ocrText,
          ocr_confidence: ocrConfidence,
        })
        .select()
        .single()

      if (dbError) {
        console.error('Database error:', dbError)
        // Clean up uploaded file if database insert fails
        await supabase.storage.from('uploads').remove([fileName])
        return NextResponse.json(
          { error: 'Failed to save file metadata' },
          { status: 500 }
        )
      }

      return NextResponse.json({
        id: fileData.id,
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type,
        ocrText: ocrText,
        ocrConfidence: ocrConfidence,
        status: 'completed'
      })

    } catch (error) {
      console.error('Upload processing error:', error)
      return NextResponse.json(
        { error: 'Failed to process upload' },
        { status: 500 }
      )
    }

  } catch (error) {
    console.error('Upload API error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

// Handle preflight requests for CORS
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  })
}